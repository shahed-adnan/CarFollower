package packfrauasmove;

import lejos.hardware.Button;
import lejos.hardware.motor.Motor;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;

public class AutonomousCarTest {
	public static double constant_distance=0.15; // 15 cm
	public static double transition_distance=0.20; // 20 cm
	public static double critical_value=0.10;// 10 cm
	
	public static void main(String[] args) {
				
		EV3UltrasonicSensor uss = new EV3UltrasonicSensor(SensorPort.S1);
		uss.enable();
		
		SampleProvider sp = uss.getDistanceMode();
		float[] sample = new float[sp.sampleSize()];
		
		double dist;
		int speed=0;
		boolean flag=true;
	while(flag!=false) {
		
		sp.fetchSample(sample, 0);
		dist=(double)sample[0];		
		
		if(dist>constant_distance + transition_distance) {
			
			while(dist>constant_distance + transition_distance) {
				
				Motor.D.forward();
				if(speed != 300) {
					speed=300;
					
				}
				Motor.D.setSpeed(speed);
				sp.fetchSample(sample, 0);
				dist=(double)sample[0];
				if(Button.ESCAPE.isDown()) flag=false; 
				
			}		
		}
		else if (constant_distance + transition_distance > dist && dist>constant_distance) {
			
			while(constant_distance + transition_distance > dist && dist>constant_distance) {
				
				Motor.D.forward();
				if(speed != 200) {
					speed=200;
					
				}
				Motor.D.setSpeed(speed);
				sp.fetchSample(sample, 0);
				dist=(double)sample[0];
				if(Button.ESCAPE.isDown()) flag=false; 
				
			}
		}
		else if (dist== constant_distance) {
			
			while(dist==constant_distance) {
				
				Motor.D.forward();
				if(speed != 100) {
					
					speed=100;
										
				}
				Motor.D.setSpeed(speed);
				sp.fetchSample(sample, 0);
				dist=(double)sample[0];
				if(Button.ESCAPE.isDown()) flag=false; 
				
			}
		}
		else if(constant_distance>dist && dist>critical_value) {
			
			while(constant_distance>dist && dist>critical_value) {
				Motor.D.forward();
				if(speed != 50) {
					
					speed=50;
									
				}
				Motor.D.setSpeed(speed);	
				sp.fetchSample(sample, 0);
				dist=(double)sample[0];
				
				
				if(Button.ESCAPE.isDown()) flag=false; 
				
			}
		}
		else if(dist<critical_value) {
			
			while(dist<critical_value) {
				
				Motor.D.stop();
				speed=0;
				sp.fetchSample(sample, 0);
				dist=(double)sample[0];
				if(Button.ESCAPE.isDown()) flag=false; 
				
			}			
		}
		
		if(dist<.05) {flag=false;break;}
		
	}
	
		uss.disable();
		uss.close();
		Motor.D.stop();		

	}

	
}
